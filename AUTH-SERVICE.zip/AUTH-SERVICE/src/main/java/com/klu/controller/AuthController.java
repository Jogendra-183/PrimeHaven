package com.klu.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.klu.entity.User;
import com.klu.service.UserService;

@RestController
@RequestMapping("/user")
public class AuthController {

	@Autowired
	private UserService service;

	@PostMapping("/signin")
	public Object signin(
			@RequestBody Map<String, String> u1) {

		return service.signinService(u1);
	}

	@PostMapping("/signup")
	public Object signup(
			@RequestBody User u1) {

		return service.signupService(u1);
	}

}